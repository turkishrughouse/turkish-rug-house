"use client"

import Link from "next/link"
import { useEffect, useMemo, useRef, useState } from "react"
import { ChevronDown, ChevronUp, House } from "lucide-react"
import { toast } from "sonner"
import { ResponsiveImage } from "@/components/ui/responsive-image"

import { getCartSummary, getCartUpdateEventName, readCart, type CartItem } from "@/lib/storefront/cart"
import { getAddressCountryConfig } from "@/lib/location/catalog"
import { pickPrimaryImage } from "@/lib/product-images"
import { useStorefrontCurrency } from "@/components/storefront/currency-provider"
import { ForgotPasswordModal } from "@/components/storefront/forgot-password-modal"

type Provider = "stripe" | "paypal" | "gpay" | "applepay" | "paytr"
type PaymentTab = "gpay" | "applepay" | "paypal" | "stripe"
type ShippingMethod = "dhl" | "ups" | "fedex"

type PublicSettings = {
  checkoutEnabled?: boolean
  enableGuestCheckout?: boolean
  defaultCurrency?: string
  currencyPosition?: "left" | "right"
  thousandSeparator?: string
  decimalSeparator?: string
  numberOfDecimals?: number
  stripeEnabled?: boolean
  googlePayEnabled?: boolean
  applePayEnabled?: boolean
  paypalEnabled?: boolean
  paytrEnabled?: boolean
  paymentDefaultProvider?: Provider
  flatShippingRate?: number
  localPickupRate?: number
  enableTaxes?: boolean
  requirePhoneAtCheckout?: boolean
  requireAddressAtCheckout?: boolean
}

type LocationCountry = {
  code: string
  name: string
}

type RegisterFieldKey =
  | "firstName"
  | "lastName"
  | "email"
  | "telephone"
  | "password"
  | "confirmPassword"
  | "privacyPolicy"

type BillingFieldKey =
  | "firstName"
  | "lastName"
  | "email"
  | "telephone"
  | "addressLine1"
  | "city"
  | "postcode"
  | "country"
  | "regionState"

const REQUEST_TIMEOUT_MS = 15000

export default function CheckoutPage() {
  const countriesInitializedRef = useRef(false)
  const statesFetchKeyRef = useRef("")

  const [items, setItems] = useState<CartItem[]>([])
  const [loading, setLoading] = useState(false)
  const [settings, setSettings] = useState<PublicSettings>({})
  const [paymentTab, setPaymentTab] = useState<PaymentTab>("stripe")
  const [shippingMethod, setShippingMethod] = useState<ShippingMethod>("dhl")
  const [openStep, setOpenStep] = useState<number | null>(1)
  const [deliverySameAsBilling, setDeliverySameAsBilling] = useState(true)
  const [orderComment, setOrderComment] = useState("")
  const [agreeTerms, setAgreeTerms] = useState(false)

  const [firstName, setFirstName] = useState("")
  const [lastName, setLastName] = useState("")
  const [customerEmail, setCustomerEmail] = useState("")
  const [customerPhone, setCustomerPhone] = useState("")
  const [company, setCompany] = useState("")
  const [addressLine1, setAddressLine1] = useState("")
  const [addressLine2, setAddressLine2] = useState("")
  const [city, setCity] = useState("")
  const [postcode, setPostcode] = useState("")
  const [country, setCountry] = useState("")
  const [regionState, setRegionState] = useState("")
  const [countryCode, setCountryCode] = useState("")
  const [countryOptions, setCountryOptions] = useState<LocationCountry[]>([])
  const [stateOptions, setStateOptions] = useState<string[]>([])
  const [loginEmail, setLoginEmail] = useState("")
  const [loginPassword, setLoginPassword] = useState("")
  const [checkoutOption, setCheckoutOption] = useState<"register" | "guest">("guest")
  const [fallbackBannerImage, setFallbackBannerImage] = useState("")
  const [authModalMode, setAuthModalMode] = useState<null | "forgot">(null)
  const [authLoading, setAuthLoading] = useState(false)
  const [registerFirstName, setRegisterFirstName] = useState("")
  const [registerLastName, setRegisterLastName] = useState("")
  const [registerEmail, setRegisterEmail] = useState("")
  const [registerPhone, setRegisterPhone] = useState("")
  const [registerPassword, setRegisterPassword] = useState("")
  const [registerPasswordConfirm, setRegisterPasswordConfirm] = useState("")
  const [registerOptIn, setRegisterOptIn] = useState(true)
  const [registerPolicyAgree, setRegisterPolicyAgree] = useState(false)
  const [showRegisterSuccess, setShowRegisterSuccess] = useState(false)
  const [registerErrors, setRegisterErrors] = useState<Partial<Record<RegisterFieldKey, string>>>({})
  const [billingErrors, setBillingErrors] = useState<Partial<Record<BillingFieldKey, string>>>({})
  const { selectedCurrency, formatUsd } = useStorefrontCurrency()
  const countryConfig = useMemo(() => getAddressCountryConfig(countryCode), [countryCode])
  const showRegionField = countryConfig.regionMode !== "none"
  const regionAsSelect = countryConfig.regionMode === "select" && stateOptions.length > 0

  const inputClassName = "h-11 w-full rounded-xl border border-slate-300 bg-white px-4 text-sm outline-none transition-colors focus:border-teal-700"
  const invalidInputClassName = "border-red-400 bg-red-50/40 focus:border-red-500"

  const setRegisterErrorValue = (field: RegisterFieldKey, _value?: string) => {
    void _value
    setRegisterErrors((current) => {
      if (!current[field]) return current
      const next = { ...current }
      delete next[field]
      return next
    })
  }

  const setBillingErrorValue = (field: BillingFieldKey, _value?: string) => {
    void _value
    setBillingErrors((current) => {
      if (!current[field]) return current
      const next = { ...current }
      delete next[field]
      return next
    })
  }

  const validateRegisterFields = () => {
    const nextErrors: Partial<Record<RegisterFieldKey, string>> = {}
    if (!registerFirstName.trim()) nextErrors.firstName = "First name is required."
    if (!registerLastName.trim()) nextErrors.lastName = "Last name is required."
    if (!registerEmail.trim()) nextErrors.email = "Email is required."
    else if (!registerEmail.includes("@")) nextErrors.email = "Enter a valid email address."
    if (!registerPhone.trim()) nextErrors.telephone = "Telephone is required."
    if (!registerPassword) nextErrors.password = "Password is required."
    if (!registerPasswordConfirm) nextErrors.confirmPassword = "Please confirm your password."
    else if (registerPassword !== registerPasswordConfirm) nextErrors.confirmPassword = "Passwords do not match."
    if (!registerPolicyAgree) nextErrors.privacyPolicy = "You must accept the Privacy Policy."

    setRegisterErrors(nextErrors)
    return Object.keys(nextErrors).length === 0
  }

  const validateBillingFields = () => {
    const nextErrors: Partial<Record<BillingFieldKey, string>> = {}
    if (!firstName.trim()) nextErrors.firstName = "First name is required."
    if (!lastName.trim()) nextErrors.lastName = "Last name is required."
    if (!customerEmail.trim()) nextErrors.email = "Email is required."
    else if (!customerEmail.includes("@")) nextErrors.email = "Enter a valid email address."
    if (!customerPhone.trim()) nextErrors.telephone = "Telephone is required."
    if (!addressLine1.trim()) nextErrors.addressLine1 = "Address line 1 is required."
    if (!city.trim()) nextErrors.city = `${countryConfig.cityLabel} is required.`
    if (!postcode.trim()) nextErrors.postcode = `${countryConfig.postalCodeLabel} is required.`
    if (!countryCode || !country.trim()) nextErrors.country = "Country is required."
    if (countryConfig.regionRequired && !regionState.trim()) nextErrors.regionState = `${countryConfig.regionLabel} is required.`

    setBillingErrors(nextErrors)
    return Object.keys(nextErrors).length === 0
  }

  useEffect(() => {
    const refresh = () => setItems(readCart())
    const eventName = getCartUpdateEventName()

    window.addEventListener(eventName, refresh)
    window.addEventListener("storage", refresh)
    const timer = window.setTimeout(refresh, 0)

    return () => {
      window.clearTimeout(timer)
      window.removeEventListener(eventName, refresh)
      window.removeEventListener("storage", refresh)
    }
  }, [])

  useEffect(() => {
    const loadSettings = async () => {
      try {
        const res = await fetch("/api/public/settings", { cache: "force-cache" })
        if (!res.ok) return
        const data = (await res.json()) as PublicSettings
        setSettings(data)

        const enabledTabs: PaymentTab[] = []
        if (data.googlePayEnabled) enabledTabs.push("gpay")
        if (data.applePayEnabled) enabledTabs.push("applepay")
        if (data.stripeEnabled) enabledTabs.push("stripe")
        if (data.paypalEnabled) enabledTabs.push("paypal")

        if (data.paymentDefaultProvider === "gpay" && enabledTabs.includes("gpay")) {
          setPaymentTab("gpay")
        } else if (data.paymentDefaultProvider === "applepay" && enabledTabs.includes("applepay")) {
          setPaymentTab("applepay")
        } else if (data.paymentDefaultProvider === "paypal" && enabledTabs.includes("paypal")) {
          setPaymentTab("paypal")
        } else if (enabledTabs.length > 0) {
          setPaymentTab(enabledTabs[0])
        }
      } catch {
        // keep defaults
      }
    }

    void loadSettings()
  }, [])

  useEffect(() => {
    const loadFallbackBanner = async () => {
      try {
        const res = await fetch("/api/v1/public/products?limit=1&sort=latest", { cache: "no-store" })
        if (!res.ok) return
        const data = (await res.json().catch(() => ({}))) as {
          products?: Array<{ image?: string; featuredImage?: string; images?: unknown }>
        }
        const product = Array.isArray(data.products) ? data.products[0] : null
        if (!product) return
        const image =
          (typeof product.image === "string" ? product.image : "") ||
          pickPrimaryImage(product.featuredImage ?? "", product.images)
        if (image) setFallbackBannerImage(image)
      } catch {
        // keep placeholder fallback
      }
    }

    void loadFallbackBanner()
  }, [])

  useEffect(() => {
    if (countriesInitializedRef.current) return
    countriesInitializedRef.current = true
    const loadCountries = async () => {
      try {
        const res = await fetch("/api/public/location/countries", { cache: "no-store" })
        if (!res.ok) return
        const json = (await res.json().catch(() => ({}))) as { countries?: LocationCountry[] }
        const rawCountries = Array.isArray(json.countries) ? json.countries : []
        if (rawCountries.length === 0) return

        const grouped = new Map<string, LocationCountry[]>()
        for (const item of rawCountries) {
          const nameKey = (item.name || "").trim().toLowerCase()
          if (!nameKey) continue
          if (!grouped.has(nameKey)) grouped.set(nameKey, [])
          grouped.get(nameKey)!.push(item)
        }

        const countries = Array.from(grouped.values()).map((sameNameItems) => {
          const preferGB = sameNameItems.find((item) => item.code === "GB")
          if (preferGB) return preferGB
          return sameNameItems[0]
        })

        countries.sort((a, b) => a.name.localeCompare(b.name))
        setCountryOptions(countries)

        const byName = countries.find((item) => item.name.toLowerCase() === country.toLowerCase())
        const current = byName || countries.find((item) => item.code === countryCode)
        if (current) {
          setCountryCode(current.code)
          setCountry(current.name)
        }
      } catch {
        // keep defaults
      }
    }
    void loadCountries()
  }, [country, countryCode])

  useEffect(() => {
    if (!countryCode) return
    if (countryConfig.regionMode !== "select") {
      setStateOptions([])
      return
    }
    const fetchKey = `${countryCode}|${country}`
    if (statesFetchKeyRef.current === fetchKey) return
    statesFetchKeyRef.current = fetchKey
    const loadStates = async () => {
      try {
        const res = await fetch(`/api/public/location/states?countryCode=${encodeURIComponent(countryCode)}&countryName=${encodeURIComponent(country)}`, {
          cache: "no-store",
        })
        if (!res.ok) {
          setStateOptions([])
          return
        }
        const json = (await res.json().catch(() => ({}))) as { states?: string[] }
        const states = Array.isArray(json.states) ? json.states : []
        setStateOptions(states)
        if (countryConfig.regionMode === "select" && regionState.trim() && !states.includes(regionState)) {
          setRegionState("")
        }
      } catch {
        setStateOptions([])
      }
    }
    void loadStates()
  }, [countryCode, country, regionState, countryConfig.regionMode])

  const summary = useMemo(() => getCartSummary(items), [items])
  const bannerImage = items[0]?.image || fallbackBannerImage || "/placeholder.jpg"
  const flatRate = Math.max(0, Number(settings.flatShippingRate || 0))
  const shippingOptions: Array<{ value: ShippingMethod; label: string; price: number }> = [
    { value: "dhl", label: "DHL", price: flatRate },
    { value: "ups", label: "UPS", price: flatRate + 4 },
    { value: "fedex", label: "FedEx", price: flatRate + 8 },
  ]
  const selectedShipping = shippingOptions.find((option) => option.value === shippingMethod) || shippingOptions[0]
  const shippingCost = selectedShipping.price
  const shippingLabel = selectedShipping.label
  const ecoTaxAmount = 0
  const vatAmount = settings.enableTaxes ? (summary.total + shippingCost) * 0.1 : 0
  const total = summary.total + shippingCost + ecoTaxAmount + vatAmount

  const enabledPaymentTabs = useMemo(() => {
    const tabs: Array<{ value: PaymentTab; label: string; enabled: boolean }> = [
      { value: "gpay", label: "GPay", enabled: Boolean(settings.googlePayEnabled) },
      { value: "applepay", label: "Apple Pay", enabled: Boolean(settings.applePayEnabled) },
      { value: "paypal", label: "PayPal", enabled: Boolean(settings.paypalEnabled) },
      { value: "stripe", label: "Stripe", enabled: Boolean(settings.stripeEnabled) },
    ]
    return tabs
  }, [settings.googlePayEnabled, settings.applePayEnabled, settings.stripeEnabled, settings.paypalEnabled])

  const provider: Provider = paymentTab
  const paymentPanel = useMemo(() => {
    if (paymentTab === "gpay") {
      return {
        title: "Google Pay",
        description: "Use Google Pay for a fast and secure checkout with your saved cards.",
      }
    }
    if (paymentTab === "applepay") {
      return {
        title: "Apple Pay",
        description: "Pay quickly with Apple Pay using Face ID or Touch ID on supported devices.",
      }
    }
    if (paymentTab === "paypal") {
      return {
        title: "PayPal",
        description: "You will be redirected to PayPal to complete payment securely.",
      }
    }
    return {
      title: "Stripe Card Payment",
      description: "Pay with Visa, MasterCard, AMEX or other cards powered by Stripe.",
    }
  }, [paymentTab])

  const startPayment = async () => {
    if (items.length === 0) {
      toast.error("Your basket is empty")
      return
    }

    if (!firstName.trim() || !lastName.trim() || !customerEmail.trim()) {
      toast.error("Please enter first name, last name and email")
      return
    }

    if (settings.requirePhoneAtCheckout && !customerPhone.trim()) {
      toast.error("Please enter your phone number")
      return
    }

    if (!countryCode || !country.trim()) {
      toast.error("Please select your country")
      return
    }

    if (!addressLine1.trim() || !city.trim() || !postcode.trim()) {
      toast.error("Please complete your address, city, and postal code")
      return
    }

    if (countryConfig.regionRequired && !regionState.trim()) {
      toast.error(`Please enter your ${countryConfig.regionLabel.toLowerCase()}`)
      return
    }

    if (!enabledPaymentTabs.some((tab) => tab.enabled)) {
      toast.error("No payment provider is enabled")
      return
    }

    if (!agreeTerms) {
      toast.error("Please accept terms & conditions")
      return
    }

    setLoading(true)
    try {
      const res = await fetch("/api/public/payments/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          provider,
          customerName: [firstName.trim(), lastName.trim()].filter(Boolean).join(" "),
          customerEmail: customerEmail.trim(),
          customerPhone: customerPhone.trim(),
          company: company.trim(),
          addressLine1: addressLine1.trim(),
          addressLine2: addressLine2.trim(),
          city: city.trim(),
          postcode: postcode.trim(),
          country: country.trim(),
          countryCode: countryCode.trim(),
          regionState: regionState.trim(),
          orderComment: orderComment.trim(),
          shippingMethod,
          displayCurrency: selectedCurrency,
          items: items.map((item) => ({
            productId: item.productId,
            quantity: item.quantity,
          })),
        }),
      })

      const json = (await res.json().catch(() => ({}))) as { error?: string; redirectUrl?: string }
      if (!res.ok || !json.redirectUrl) {
        throw new Error(json.error || "Checkout could not be started")
      }

      window.location.assign(json.redirectUrl)
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Checkout failed")
    } finally {
      setLoading(false)
    }
  }

  const submitReturningCustomer = async () => {
    if (!loginEmail.trim() || !loginPassword.trim()) {
      toast.error("Please enter email and password")
      return
    }
    setLoading(true)
    try {
      const res = await fetch("/api/auth/login?portal=customer", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: loginEmail.trim(), password: loginPassword }),
      })
      const json = (await res.json().catch(() => ({}))) as { error?: string }
      if (!res.ok) throw new Error(json.error || "Login failed")
      setCustomerEmail(loginEmail.trim())
      setOpenStep(2)
      toast.success("Login successful")
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Login failed")
    } finally {
      setLoading(false)
    }
  }

  const submitRegisterFromCheckout = async () => {
    if (!validateRegisterFields()) {
      toast.error("Please complete the required registration fields")
      return
    }
    setAuthLoading(true)
    let timeoutId: number | undefined
    try {
      const controller = new AbortController()
      timeoutId = window.setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS)
      const fullName = `${registerFirstName} ${registerLastName}`.trim()
      const res = await fetch("/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        signal: controller.signal,
        body: JSON.stringify({
          name: fullName,
          email: registerEmail.trim(),
          phone: registerPhone.trim(),
          password: registerPassword,
          marketingOptIn: registerOptIn,
          source: "account",
        }),
      })
      window.clearTimeout(timeoutId)
      const data = (await res.json().catch(() => ({}))) as { error?: string }
      if (!res.ok) {
        throw new Error(data.error || "Registration failed")
      }
      setCustomerEmail(registerEmail.trim())
      setCustomerPhone(registerPhone.trim())
      setFirstName(registerFirstName.trim())
      setLastName(registerLastName.trim())
      setLoginEmail(registerEmail.trim())
      setShowRegisterSuccess(true)
      setRegisterFirstName("")
      setRegisterLastName("")
      setRegisterEmail("")
      setRegisterPhone("")
      setRegisterPassword("")
      setRegisterPasswordConfirm("")
      setRegisterPolicyAgree(false)
      setRegisterErrors({})
      setOpenStep(2)
      toast.success("Account created")
    } catch (error) {
      if (error instanceof Error && error.name === "AbortError") {
        toast.error("Request timed out. Please try again.")
      } else {
        toast.error(error instanceof Error ? error.message : "Registration failed")
      }
    } finally {
      if (timeoutId) window.clearTimeout(timeoutId)
      setAuthLoading(false)
    }
  }

  if (items.length === 0) {
    return (
      <div className="min-h-screen bg-[#f5f5f5]">
        <section className="relative overflow-hidden border-b border-slate-200">
          <ResponsiveImage
            src={bannerImage}
            alt="Checkout banner"
            fill
            priority
            sizes="100vw"
            className="absolute inset-0 object-cover object-center"
          />
          <div className="absolute inset-0 bg-black/35" />
          <div className="relative mx-auto w-full max-w-[1200px] px-6 py-12 text-center">
            <h1 className="text-4xl font-semibold text-white">Checkout</h1>
            <div className="mt-2 flex items-center justify-center gap-3 text-sm text-slate-100 md:text-base">
              <Link href="/" className="inline-flex items-center gap-2 hover:text-white">
                <House className="h-4 w-4" />
                Home
              </Link>
              <span>/</span>
              <Link href="/basket" className="hover:text-white">Shopping Cart</Link>
              <span>/</span>
              <span>Checkout</span>
            </div>
          </div>
        </section>
        <div className="mx-auto w-full max-w-[1200px] px-6 py-10">
          <div className="rounded-md border border-slate-200 bg-white p-10 text-center">
            <p className="text-slate-600">Your cart is empty.</p>
            <Link href="/shop" className="mt-4 inline-flex h-10 items-center rounded-md bg-teal-700 px-4 text-sm font-semibold text-white hover:bg-teal-800">
              Continue Shopping
            </Link>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-[#f5f5f5]">
      <section className="relative overflow-hidden border-b border-slate-200">
        <ResponsiveImage
          src={bannerImage}
          alt="Checkout banner"
          fill
          priority
          sizes="100vw"
          className="absolute inset-0 object-cover object-center"
        />
        <div className="absolute inset-0 bg-black/35" />
        <div className="relative mx-auto w-full max-w-[1200px] px-4 py-10 text-center sm:px-6 sm:py-12">
          <h1 className="text-3xl font-semibold text-white sm:text-4xl">Checkout</h1>
          <div className="mt-2 flex flex-wrap items-center justify-center gap-2 text-sm text-slate-100 md:text-base">
            <Link href="/" className="inline-flex items-center gap-2 hover:text-white">
              <House className="h-4 w-4" />
              Home
            </Link>
            <span>/</span>
            <Link href="/basket" className="hover:text-white">Shopping Cart</Link>
            <span>/</span>
            <span>Checkout</span>
          </div>
        </div>
      </section>

      <div className="mx-auto w-full max-w-[1600px] px-3 py-8 sm:px-4 sm:py-10 lg:px-10">
        <div className="border-t border-slate-200">
          <div className="border-b border-slate-200">
            <button type="button" onClick={() => setOpenStep(openStep === 1 ? null : 1)} className="flex h-16 w-full items-center justify-between text-left">
              <span className="text-base font-semibold leading-none text-teal-800">Step 1: <span className="text-base font-semibold text-slate-900">Checkout Options</span></span>
              {openStep === 1 ? <ChevronUp className="h-6 w-6 text-slate-700" /> : <ChevronDown className="h-6 w-6 text-slate-700" />}
            </button>
            {openStep === 1 ? (
              <div className="pb-7">
                <div className="grid grid-cols-1 gap-10 lg:grid-cols-2">
                  <div>
                    <h3 className="text-2xl font-semibold leading-none text-slate-900">Returning Customer</h3>
                    <div className="mt-10 space-y-4">
                      <div className="grid grid-cols-1 gap-2 sm:grid-cols-[150px_1fr] sm:items-center sm:gap-4">
                        <label className="text-base text-slate-600">E-Mail</label>
                        <input
                          value={loginEmail}
                          onChange={(e) => setLoginEmail(e.target.value)}
                          className="h-11 rounded border border-slate-300 px-4 text-base"
                          placeholder="E-Mail"
                        />
                      </div>
                      <div className="grid grid-cols-1 gap-2 sm:grid-cols-[150px_1fr] sm:items-center sm:gap-4">
                        <label className="text-base text-slate-600">Password</label>
                        <input
                          type="password"
                          value={loginPassword}
                          onChange={(e) => setLoginPassword(e.target.value)}
                          className="h-11 rounded border border-slate-300 px-4 text-base"
                          placeholder="Password"
                        />
                      </div>
                      <button type="button" onClick={() => setAuthModalMode("forgot")} className="inline-block text-base text-teal-800 underline">
                        Forgotten Password
                      </button>
                    </div>
                    <button
                      type="button"
                      onClick={submitReturningCustomer}
                      disabled={loading}
                      className="mt-10 inline-flex h-12 w-full items-center justify-center rounded-full bg-teal-700 text-base font-semibold text-white hover:bg-teal-800 disabled:opacity-60"
                    >
                      Login
                    </button>
                  </div>

                  <div>
                    <h3 className="text-2xl font-semibold leading-none text-slate-900">New Customer</h3>
                    <div className="mt-10 space-y-3 text-lg text-slate-700">
                      <label className="flex items-center gap-3">
                        <input
                          type="radio"
                          checked={checkoutOption === "register"}
                          onChange={() => {
                            setCheckoutOption("register")
                            setShowRegisterSuccess(false)
                          }}
                        />
                        Register Account
                      </label>
                      <label className="flex items-center gap-3">
                        <input
                          type="radio"
                          checked={checkoutOption === "guest"}
                          onChange={() => setCheckoutOption("guest")}
                        />
                        Guest Checkout
                      </label>
                    </div>
                    <p className="mt-6 text-base leading-relaxed text-slate-600">
                      By creating an account you will be able to shop faster, be up to date on an order’s status, and keep track of the orders you have previously made.
                    </p>
                    <div
                      className={`grid transition-all duration-200 ease-out ${
                        checkoutOption === "register" ? "mt-6 grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0"
                      }`}
                    >
                      <div className="overflow-hidden">
                        <div className="rounded-2xl border border-[#dce3ed] bg-[#f8fafc] p-5 shadow-[0_10px_28px_rgba(15,23,42,0.05)]">
                          <div className="grid gap-4 md:grid-cols-2">
                            <div className="space-y-1.5">
                              <label className="text-sm font-medium text-slate-700">First Name</label>
                              <input value={registerFirstName} onChange={(event) => { setRegisterFirstName(event.target.value); setRegisterErrorValue("firstName", event.target.value) }} className={`${inputClassName} ${registerErrors.firstName ? invalidInputClassName : ""}`} placeholder="First Name" />
                              {registerErrors.firstName ? <p className="text-xs text-red-600">{registerErrors.firstName}</p> : null}
                            </div>
                            <div className="space-y-1.5">
                              <label className="text-sm font-medium text-slate-700">Last Name</label>
                              <input value={registerLastName} onChange={(event) => { setRegisterLastName(event.target.value); setRegisterErrorValue("lastName", event.target.value) }} className={`${inputClassName} ${registerErrors.lastName ? invalidInputClassName : ""}`} placeholder="Last Name" />
                              {registerErrors.lastName ? <p className="text-xs text-red-600">{registerErrors.lastName}</p> : null}
                            </div>
                            <div className="space-y-1.5">
                              <label className="text-sm font-medium text-slate-700">Email</label>
                              <input type="email" value={registerEmail} onChange={(event) => { setRegisterEmail(event.target.value); setRegisterErrorValue("email", event.target.value) }} className={`${inputClassName} ${registerErrors.email ? invalidInputClassName : ""}`} placeholder="Email" />
                              {registerErrors.email ? <p className="text-xs text-red-600">{registerErrors.email}</p> : null}
                            </div>
                            <div className="space-y-1.5">
                              <label className="text-sm font-medium text-slate-700">Telephone</label>
                              <input value={registerPhone} onChange={(event) => { setRegisterPhone(event.target.value); setRegisterErrorValue("telephone", event.target.value) }} className={`${inputClassName} ${registerErrors.telephone ? invalidInputClassName : ""}`} placeholder="Telephone" />
                              {registerErrors.telephone ? <p className="text-xs text-red-600">{registerErrors.telephone}</p> : null}
                            </div>
                            <div className="space-y-1.5">
                              <label className="text-sm font-medium text-slate-700">Password</label>
                              <input type="password" value={registerPassword} onChange={(event) => { setRegisterPassword(event.target.value); setRegisterErrorValue("password", event.target.value) }} className={`${inputClassName} ${registerErrors.password ? invalidInputClassName : ""}`} placeholder="Password" />
                              {registerErrors.password ? <p className="text-xs text-red-600">{registerErrors.password}</p> : null}
                            </div>
                            <div className="space-y-1.5">
                              <label className="text-sm font-medium text-slate-700">Confirm Password</label>
                              <input type="password" value={registerPasswordConfirm} onChange={(event) => { setRegisterPasswordConfirm(event.target.value); setRegisterErrorValue("confirmPassword", event.target.value) }} className={`${inputClassName} ${registerErrors.confirmPassword ? invalidInputClassName : ""}`} placeholder="Confirm Password" />
                              {registerErrors.confirmPassword ? <p className="text-xs text-red-600">{registerErrors.confirmPassword}</p> : null}
                            </div>
                          </div>
                          <div className="mt-4 flex flex-col gap-3">
                            <label className="flex w-full items-start gap-3 text-sm leading-6 text-slate-700">
                              <input className="mt-1 h-4 w-4 shrink-0" type="checkbox" checked={registerPolicyAgree} onChange={(event) => { setRegisterPolicyAgree(event.target.checked); if (event.target.checked) setRegisterErrors((current) => { const next = { ...current }; delete next.privacyPolicy; return next }) }} />
                              <span>
                                I have read and agree to the{" "}
                                <Link href="/info/privacy-policy" className="text-teal-700 underline underline-offset-4">
                                  Privacy Policy
                                </Link>
                              </span>
                            </label>
                            <label className="flex w-full items-start gap-3 text-sm leading-6 text-slate-700">
                              <input className="mt-1 h-4 w-4 shrink-0" type="checkbox" checked={registerOptIn} onChange={(event) => setRegisterOptIn(event.target.checked)} />
                              <span>Subscribe to the newsletter</span>
                            </label>
                            {registerErrors.privacyPolicy ? <p className="text-xs text-red-600">{registerErrors.privacyPolicy}</p> : null}
                          </div>
                          {showRegisterSuccess ? (
                            <div className="mt-4 rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-900">
                              Account created successfully. Continue with billing details below.
                            </div>
                          ) : null}
                        </div>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        if (checkoutOption === "register") {
                          void submitRegisterFromCheckout()
                          return
                        }
                        setOpenStep(2)
                      }}
                      disabled={authLoading}
                      className="mt-10 inline-flex h-12 w-full items-center justify-center rounded-full bg-teal-700 text-base font-semibold text-white hover:bg-teal-800 disabled:opacity-60"
                    >
                      {checkoutOption === "register" ? (authLoading ? "Please wait..." : "Create Account & Continue") : "Continue"}
                    </button>
                  </div>
                </div>
              </div>
            ) : null}
          </div>

          <div className="border-b border-slate-200">
            <button type="button" onClick={() => setOpenStep(openStep === 2 ? null : 2)} className="flex h-16 w-full items-center justify-between text-left">
              <span className="text-base font-semibold leading-none text-teal-800">Step 2: <span className="text-base font-semibold text-slate-900">Billing Details</span></span>
              {openStep === 2 ? <ChevronUp className="h-6 w-6 text-slate-700" /> : <ChevronDown className="h-6 w-6 text-slate-700" />}
            </button>
            {openStep === 2 ? (
              <div className="pb-8">
                <div className="grid grid-cols-1 gap-10 lg:grid-cols-2">
                  <div>
                    <h3 className="text-2xl font-semibold leading-none text-slate-900">Your Personal Details</h3>
                    <div className="mt-10 space-y-4">
                      <div className="grid grid-cols-1 gap-2 sm:grid-cols-[150px_1fr] sm:items-center sm:gap-4">
                        <label className="text-base text-slate-600">First Name *</label>
                        <div>
                          <input value={firstName} onChange={(e) => { setFirstName(e.target.value); setBillingErrorValue("firstName", e.target.value) }} className={`h-11 w-full rounded border px-4 text-base ${billingErrors.firstName ? "border-red-400 bg-red-50/40" : "border-slate-300"}`} placeholder="First Name" />
                          {billingErrors.firstName ? <p className="mt-1 text-xs text-red-600">{billingErrors.firstName}</p> : null}
                        </div>
                      </div>
                      <div className="grid grid-cols-1 gap-2 sm:grid-cols-[150px_1fr] sm:items-center sm:gap-4">
                        <label className="text-base text-slate-600">Last Name *</label>
                        <div>
                          <input value={lastName} onChange={(e) => { setLastName(e.target.value); setBillingErrorValue("lastName", e.target.value) }} className={`h-11 w-full rounded border px-4 text-base ${billingErrors.lastName ? "border-red-400 bg-red-50/40" : "border-slate-300"}`} placeholder="Last Name" />
                          {billingErrors.lastName ? <p className="mt-1 text-xs text-red-600">{billingErrors.lastName}</p> : null}
                        </div>
                      </div>
                      <div className="grid grid-cols-1 gap-2 sm:grid-cols-[150px_1fr] sm:items-center sm:gap-4">
                        <label className="text-base text-slate-600">E-Mail *</label>
                        <div>
                          <input value={customerEmail} onChange={(e) => { setCustomerEmail(e.target.value); setBillingErrorValue("email", e.target.value) }} type="email" className={`h-11 w-full rounded border px-4 text-base ${billingErrors.email ? "border-red-400 bg-red-50/40" : "border-slate-300"}`} placeholder="E-Mail" />
                          {billingErrors.email ? <p className="mt-1 text-xs text-red-600">{billingErrors.email}</p> : null}
                        </div>
                      </div>
                      <div className="grid grid-cols-1 gap-2 sm:grid-cols-[150px_1fr] sm:items-center sm:gap-4">
                        <label className="text-base text-slate-600">Telephone *</label>
                        <div>
                          <input value={customerPhone} onChange={(e) => { setCustomerPhone(e.target.value); setBillingErrorValue("telephone", e.target.value) }} className={`h-11 w-full rounded border px-4 text-base ${billingErrors.telephone ? "border-red-400 bg-red-50/40" : "border-slate-300"}`} placeholder="Telephone" />
                          {billingErrors.telephone ? <p className="mt-1 text-xs text-red-600">{billingErrors.telephone}</p> : null}
                        </div>
                      </div>
                    </div>
                  </div>

                  <div>
                    <h3 className="text-2xl font-semibold leading-none text-slate-900">Your Address</h3>
                    <div className="mt-10 space-y-4">
                      <div className="grid grid-cols-1 gap-2 sm:grid-cols-[150px_1fr] sm:items-center sm:gap-4">
                        <label className="text-base text-slate-600">Company</label>
                        <input value={company} onChange={(e) => setCompany(e.target.value)} className="h-11 rounded border border-slate-300 px-4 text-base" placeholder="Company" />
                      </div>
                      <div className="grid grid-cols-1 gap-2 sm:grid-cols-[150px_1fr] sm:items-center sm:gap-4">
                        <label className="text-base text-slate-600">Address 1 *</label>
                        <div>
                          <input value={addressLine1} onChange={(e) => { setAddressLine1(e.target.value); setBillingErrorValue("addressLine1", e.target.value) }} className={`h-11 w-full rounded border px-4 text-base ${billingErrors.addressLine1 ? "border-red-400 bg-red-50/40" : "border-slate-300"}`} placeholder="Address 1" />
                          {billingErrors.addressLine1 ? <p className="mt-1 text-xs text-red-600">{billingErrors.addressLine1}</p> : null}
                        </div>
                      </div>
                      <div className="grid grid-cols-1 gap-2 sm:grid-cols-[150px_1fr] sm:items-center sm:gap-4">
                        <label className="text-base text-slate-600">Address 2</label>
                        <input value={addressLine2} onChange={(e) => setAddressLine2(e.target.value)} className="h-11 rounded border border-slate-300 px-4 text-base" placeholder="Address 2" />
                      </div>
                      <div className="grid grid-cols-1 gap-2 sm:grid-cols-[150px_1fr] sm:items-center sm:gap-4">
                        <label className="text-base text-slate-600">City *</label>
                        <div>
                          <input
                            value={city}
                            onChange={(e) => { setCity(e.target.value); setBillingErrorValue("city", e.target.value) }}
                            className={`h-11 w-full rounded border px-4 text-base ${billingErrors.city ? "border-red-400 bg-red-50/40" : "border-slate-300"}`}
                            placeholder={countryConfig.cityLabel}
                            autoComplete="address-level2"
                          />
                          {billingErrors.city ? <p className="mt-1 text-xs text-red-600">{billingErrors.city}</p> : null}
                        </div>
                      </div>
                      <div className="grid grid-cols-1 gap-2 sm:grid-cols-[150px_1fr] sm:items-center sm:gap-4">
                        <label className="text-base text-slate-600">{countryConfig.postalCodeLabel} *</label>
                        <div>
                          <input
                            value={postcode}
                            onChange={(e) => { setPostcode(e.target.value); setBillingErrorValue("postcode", e.target.value) }}
                            className={`h-11 w-full rounded border px-4 text-base ${billingErrors.postcode ? "border-red-400 bg-red-50/40" : "border-slate-300"}`}
                            placeholder={countryConfig.postalCodeLabel}
                            autoComplete="postal-code"
                          />
                          {billingErrors.postcode ? <p className="mt-1 text-xs text-red-600">{billingErrors.postcode}</p> : null}
                        </div>
                      </div>
                      <div className="grid grid-cols-1 gap-2 sm:grid-cols-[150px_1fr] sm:items-center sm:gap-4">
                        <label className="text-base text-slate-600">Country *</label>
                        <div>
                          <select
                            value={countryCode}
                            onChange={(e) => {
                              const code = e.target.value
                              setCountryCode(code)
                              const selected = countryOptions.find((item) => item.code === code)
                              setCountry(selected?.name || "")
                              setRegionState("")
                              setBillingErrorValue("country", code)
                              setBillingErrors((current) => {
                                if (!current.regionState) return current
                                const next = { ...current }
                                delete next.regionState
                                return next
                              })
                            }}
                            className={`h-11 w-full rounded border bg-white px-4 text-base ${billingErrors.country ? "border-red-400 bg-red-50/40" : "border-slate-300"}`}
                            autoComplete="country"
                          >
                            <option value="">Select country</option>
                            {countryOptions.length > 0 ? countryOptions.map((item) => (
                              <option key={item.code} value={item.code}>{item.name}</option>
                            )) : countryCode ? <option value={countryCode}>{country}</option> : null}
                          </select>
                          {billingErrors.country ? <p className="mt-1 text-xs text-red-600">{billingErrors.country}</p> : null}
                        </div>
                      </div>
                      {showRegionField ? (
                        <div className="grid grid-cols-1 gap-2 sm:grid-cols-[150px_1fr] sm:items-center sm:gap-4">
                          <label className="text-base text-slate-600">
                            {countryConfig.regionLabel}
                            {countryConfig.regionRequired ? " *" : ""}
                          </label>
                          {regionAsSelect ? (
                            <div>
                              <select
                                value={regionState}
                                onChange={(e) => { setRegionState(e.target.value); setBillingErrorValue("regionState", e.target.value) }}
                                className={`h-11 w-full rounded border bg-white px-4 text-base ${billingErrors.regionState ? "border-red-400 bg-red-50/40" : "border-slate-300"}`}
                                autoComplete="address-level1"
                              >
                                <option value="">{`Select ${countryConfig.regionLabel}`}</option>
                                {stateOptions.map((stateName) => (
                                  <option key={stateName} value={stateName}>{stateName}</option>
                                ))}
                              </select>
                              {billingErrors.regionState ? <p className="mt-1 text-xs text-red-600">{billingErrors.regionState}</p> : null}
                            </div>
                          ) : (
                            <div>
                              <input
                                value={regionState}
                                onChange={(e) => { setRegionState(e.target.value); setBillingErrorValue("regionState", e.target.value) }}
                                className={`h-11 w-full rounded border px-4 text-base ${billingErrors.regionState ? "border-red-400 bg-red-50/40" : "border-slate-300"}`}
                                placeholder={countryConfig.regionLabel}
                                autoComplete="address-level1"
                              />
                              {billingErrors.regionState ? <p className="mt-1 text-xs text-red-600">{billingErrors.regionState}</p> : null}
                            </div>
                          )}
                        </div>
                      ) : null}
                    </div>
                  </div>
                </div>
                <label className="mt-8 inline-flex items-center gap-2 text-base text-slate-700">
                  <input type="checkbox" checked={deliverySameAsBilling} onChange={(e) => setDeliverySameAsBilling(e.target.checked)} />
                  My delivery and billing addresses are the same.
                </label>
                <button type="button" onClick={() => {
                  if (!validateBillingFields()) {
                    toast.error("Please complete the required billing details")
                    return
                  }
                  setOpenStep(3)
                }} className="mt-6 inline-flex h-12 w-full items-center justify-center rounded-full bg-teal-700 text-base font-semibold text-white hover:bg-teal-800">
                  Continue
                </button>
              </div>
            ) : null}
          </div>

          <div className="border-b border-slate-200">
            <button type="button" onClick={() => setOpenStep(openStep === 3 ? null : 3)} className="flex h-16 w-full items-center justify-between text-left">
              <span className="text-base font-semibold leading-none text-teal-800">Step 3: <span className="text-base font-semibold text-slate-900">Delivery Details</span></span>
              {openStep === 3 ? <ChevronUp className="h-6 w-6 text-slate-700" /> : <ChevronDown className="h-6 w-6 text-slate-700" />}
            </button>
            {openStep === 3 ? (
              <div className="pb-8">
                <p className="text-base text-slate-600">
                  {deliverySameAsBilling
                    ? "Delivery address will be the same as billing details."
                    : "Delivery address will be requested after billing details."}
                </p>
                <button type="button" onClick={() => setOpenStep(4)} className="mt-6 inline-flex h-12 w-full items-center justify-center rounded-full bg-teal-700 text-lg font-semibold text-white hover:bg-teal-800">
                  Continue
                </button>
              </div>
            ) : null}
          </div>

          <div className="border-b border-slate-200">
            <button type="button" onClick={() => setOpenStep(openStep === 4 ? null : 4)} className="flex h-16 w-full items-center justify-between text-left">
              <span className="text-base font-semibold leading-none text-teal-800">Step 4: <span className="text-base font-semibold text-slate-900">Delivery Method</span></span>
              {openStep === 4 ? <ChevronUp className="h-6 w-6 text-slate-700" /> : <ChevronDown className="h-6 w-6 text-slate-700" />}
            </button>
            {openStep === 4 ? (
              <div className="pb-8">
                <p className="text-base text-slate-600">Please select the preferred shipping method to use on this order.</p>
                <div className="mt-5 grid grid-cols-1 gap-3 md:grid-cols-3">
                  {shippingOptions.map((option) => (
                    <button
                      key={option.value}
                      type="button"
                      onClick={() => setShippingMethod(option.value)}
                      className={`rounded-lg border px-4 py-4 text-left transition-colors ${
                        shippingMethod === option.value
                          ? "border-teal-700 bg-teal-50"
                          : "border-slate-300 bg-white hover:bg-slate-50"
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div>
                          {option.value === "dhl" ? (
                            <span className="inline-flex rounded bg-[#ffcc00] px-3 py-1 text-2xl font-black tracking-tight text-[#d40511]">DHL</span>
                          ) : null}
                          {option.value === "ups" ? (
                            <span className="inline-flex rounded border-2 border-[#5b3a29] bg-[#f4c542] px-3 py-1 text-2xl font-black tracking-tight text-[#5b3a29]">UPS</span>
                          ) : null}
                          {option.value === "fedex" ? (
                            <span className="inline-flex rounded px-1 py-1 text-2xl font-black tracking-tight">
                              <span className="text-[#4d148c]">Fed</span>
                              <span className="text-[#ff6600]">Ex</span>
                            </span>
                          ) : null}
                        </div>
                        <span className="text-sm font-semibold text-slate-500">
                          {shippingMethod === option.value ? "Selected" : "Select"}
                        </span>
                      </div>
                      <p className="mt-3 text-base text-slate-700">
                        {option.label} - {formatUsd(option.price)}
                      </p>
                    </button>
                  ))}
                </div>
                <h4 className="mt-6 text-xl font-semibold text-slate-700">Add Comments About Your Order</h4>
                <textarea
                  value={orderComment}
                  onChange={(e) => setOrderComment(e.target.value)}
                  className="mt-3 min-h-[170px] w-full rounded border border-slate-300 px-3 py-3 text-base"
                />
                <button type="button" onClick={() => setOpenStep(5)} className="mt-6 inline-flex h-12 w-full items-center justify-center rounded-full bg-teal-700 text-lg font-semibold text-white hover:bg-teal-800">
                  Continue
                </button>
              </div>
            ) : null}
          </div>

          <div className="border-b border-slate-200">
            <button type="button" onClick={() => setOpenStep(openStep === 5 ? null : 5)} className="flex h-16 w-full items-center justify-between text-left">
              <span className="text-base font-semibold leading-none text-teal-800">Step 5: <span className="text-base font-semibold text-slate-900">Payment Method</span></span>
              {openStep === 5 ? <ChevronUp className="h-6 w-6 text-slate-700" /> : <ChevronDown className="h-6 w-6 text-slate-700" />}
            </button>
            {openStep === 5 ? (
              <div className="pb-8">
                <p className="text-base text-slate-600">Please select the preferred payment method to use on this order.</p>
                <div className="mt-4 grid grid-cols-2 gap-3 md:grid-cols-4">
                  {enabledPaymentTabs.map((tab) => (
                    <button
                      key={tab.value}
                      type="button"
                      disabled={!tab.enabled}
                      onClick={() => setPaymentTab(tab.value)}
                      className={`h-12 rounded border text-base font-semibold transition-colors ${
                        paymentTab === tab.value
                          ? "border-teal-700 bg-teal-700 text-white"
                          : "border-slate-300 bg-white text-slate-700 hover:bg-slate-50"
                      } disabled:cursor-not-allowed disabled:opacity-40`}
                    >
                      {tab.label}
                    </button>
                  ))}
                </div>
                <div className="mt-4 rounded-lg border border-slate-300 bg-white p-4">
                  <h5 className="text-base font-semibold text-slate-900">{paymentPanel.title}</h5>
                  <p className="mt-2 text-base text-slate-600">{paymentPanel.description}</p>
                  {paymentTab === "stripe" ? (
                    <div className="mt-4 rounded-2xl border border-emerald-100 bg-emerald-50/70 px-4 py-4 text-sm leading-6 text-slate-700">
                      Card details are entered securely on Stripe after you confirm the order.
                      We do not store your card number, expiry date, or CVC in our database.
                    </div>
                  ) : null}
                  {paymentTab === "paypal" ? (
                    <p className="mt-4 rounded bg-slate-50 p-3 text-sm text-slate-700">
                      After you click Confirm Order, you will continue on PayPal.
                    </p>
                  ) : null}
                  {paymentTab === "gpay" || paymentTab === "applepay" ? (
                    <div className="mt-4 rounded-2xl border border-slate-200 bg-slate-50 px-4 py-4 text-sm leading-6 text-slate-700">
                      {paymentTab === "gpay"
                        ? "You will continue to Google Pay on Stripe's secure payment page."
                        : "You will continue to Apple Pay on Stripe's secure payment page."}
                    </div>
                  ) : null}
                </div>
                <h4 className="mt-6 text-xl font-semibold text-slate-700">Add Comments About Your Order</h4>
                <textarea
                  value={orderComment}
                  onChange={(e) => setOrderComment(e.target.value)}
                  className="mt-3 min-h-[170px] w-full rounded border border-slate-300 px-3 py-3 text-base"
                />
                <label className="mt-5 inline-flex items-center gap-2 text-base text-slate-700">
                  <input type="checkbox" checked={agreeTerms} onChange={(e) => setAgreeTerms(e.target.checked)} />
                  I have read and agree to the <Link href="/info/terms" className="text-teal-800 underline">Terms & Conditions</Link>
                </label>
                <button type="button" onClick={() => setOpenStep(6)} className="mt-6 inline-flex h-12 w-full items-center justify-center rounded-full bg-teal-700 text-lg font-semibold text-white hover:bg-teal-800">
                  Continue
                </button>
              </div>
            ) : null}
          </div>

          <div className="border-b border-slate-200">
            <button type="button" onClick={() => setOpenStep(openStep === 6 ? null : 6)} className="flex h-16 w-full items-center justify-between text-left">
              <span className="text-base font-semibold leading-none text-teal-800">Step 6: <span className="text-base font-semibold text-slate-900">Confirm Order</span></span>
              {openStep === 6 ? <ChevronUp className="h-6 w-6 text-slate-700" /> : <ChevronDown className="h-6 w-6 text-slate-700" />}
            </button>
            {openStep === 6 ? (
              <div className="pb-8">
                <div className="overflow-hidden border border-slate-300">
                  <div className="overflow-x-auto">
                  <div className="min-w-[760px]">
                  <div className="grid grid-cols-[2.2fr_1fr_0.9fr_0.9fr_0.9fr] bg-slate-50 text-[15px] font-semibold text-slate-700">
                    <div className="border-r border-slate-300 p-3">Product Name</div>
                    <div className="border-r border-slate-300 p-3">Model</div>
                    <div className="border-r border-slate-300 p-3 text-right">Quantity</div>
                    <div className="border-r border-slate-300 p-3 text-right">Unit Price</div>
                    <div className="p-3 text-right">Total</div>
                  </div>
                  {items.map((item) => (
                    <div key={item.productId} className="grid grid-cols-[2.2fr_1fr_0.9fr_0.9fr_0.9fr] border-t border-slate-300 text-[15px] text-slate-700">
                      <div className="border-r border-slate-300 p-3">
                        <Link href={`/product/${item.slug}`} className="underline decoration-dotted underline-offset-4">
                          {item.title}
                        </Link>
                      </div>
                      <div className="border-r border-slate-300 p-3">model-{item.productId.slice(-4)}</div>
                      <div className="border-r border-slate-300 p-3 text-right">{item.quantity}</div>
                      <div className="border-r border-slate-300 p-3 text-right">{formatUsd(item.price)}</div>
                      <div className="p-3 text-right">{formatUsd(item.price * item.quantity)}</div>
                    </div>
                  ))}
                  <div className="grid grid-cols-[4.1fr_0.9fr] border-t border-slate-300 text-[15px]">
                    <div className="border-r border-slate-300 p-3 text-right font-semibold text-slate-700">Sub-Total:</div>
                    <div className="p-3 text-right">{formatUsd(summary.total)}</div>
                  </div>
                  <div className="grid grid-cols-[4.1fr_0.9fr] border-t border-slate-300 text-[15px]">
                    <div className="border-r border-slate-300 p-3 text-right font-semibold text-slate-700">{shippingLabel} Shipping:</div>
                    <div className="p-3 text-right">{formatUsd(shippingCost)}</div>
                  </div>
                  <div className="grid grid-cols-[4.1fr_0.9fr] border-t border-slate-300 text-[15px]">
                    <div className="border-r border-slate-300 p-3 text-right font-semibold text-slate-700">Eco Tax (-2.00):</div>
                    <div className="p-3 text-right">{formatUsd(ecoTaxAmount)}</div>
                  </div>
                  <div className="grid grid-cols-[4.1fr_0.9fr] border-t border-slate-300 text-[15px]">
                    <div className="border-r border-slate-300 p-3 text-right font-semibold text-slate-700">VAT (20%):</div>
                    <div className="p-3 text-right">{formatUsd(vatAmount)}</div>
                  </div>
                  <div className="grid grid-cols-[4.1fr_0.9fr] border-t border-slate-300 text-[18px] font-semibold">
                    <div className="border-r border-slate-300 p-3 text-right text-slate-700">Total:</div>
                    <div className="p-3 text-right">{formatUsd(total)}</div>
                  </div>
                  </div>
                  </div>
                </div>
                <button
                  type="button"
                  disabled={loading}
                  onClick={startPayment}
                  className="mt-7 inline-flex h-14 w-full items-center justify-center rounded-full bg-teal-700 text-2xl font-semibold text-white hover:bg-teal-800 disabled:opacity-60"
                >
                  {loading ? "Please wait..." : "Confirm Order"}
                </button>
              </div>
            ) : null}
          </div>
        </div>
      </div>

      <ForgotPasswordModal
        open={authModalMode === "forgot"}
        onClose={() => setAuthModalMode(null)}
        initialEmail={loginEmail}
      />

    </div>
  )
}
